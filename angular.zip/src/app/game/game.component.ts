import { Component, OnInit } from '@angular/core';
import Phaser from 'phaser';

class NewScene extends Phaser.Scene {
  green: any;
  blue: any;
  greenKeys: any;
  blueKeys: any;
  demo: any;
  hueso: any;
  huesoCopy: any;
  flecha: any;
  result:any;
  debug: any;

  constructor() {
    super({ key: 'new' });
  }

   preload() {

    this.load.image('grid', 'assets/images/blue.png');
    this.load.image('atari', 'assets/images/green.png');
    this.load.image('sonic', 'assets/images/blue.png');

    
}



 create() {

    this.add.sprite(0, 0, 'grid');

    let group = this.add.group();
// @ts-ignore
    group.inputEnableChildren = true;

    let atari = group.create(32, 100, 'atari');

  
    atari.inputEnabled = true;
    atari.input.enableDrag();
    atari.events.onDragStart.add(this.onDragStart, this);
    atari.events.onDragStop.add(this.onDragStop, this);

    let sonic = group.create(300, 200, 'sonic');

    sonic.inputEnabled = true;
    sonic.input.enableDrag();
    sonic.events.onDragStart.add(this.onDragStart, this);
    sonic.events.onDragStop.add(this.onDragStop, this);
// @ts-ignore
    group.onChildInputDown.add(this.onDown, this);

}

 onDown(sprite, pointer) {

    this.result = "Down " + sprite.key;

 
    console.log('down', sprite.key);

}

 onDragStart(sprite, pointer) {

    this.result = "Dragging " + sprite.key;

}

 onDragStop(sprite, pointer) {

    this.result = sprite.key + " dropped at x:" + pointer.x + " y: " + pointer.y;

    if (pointer.y > 400)
    {
        console.log('input disabled on', sprite.key);
        sprite.input.enabled = false;

        sprite.sendToBack();
    }

}

 render() {

    this.debug.text(this.result, 10, 20);

}


 
}

@Component({
  selector: 'app-game',
  templateUrl: './game.component.html',
  styleUrls: ['./game.component.scss']
})
export class GameComponent implements OnInit {
  phaserGame: Phaser.Game;
  config: Phaser.Types.Core.GameConfig;

  constructor() {
    this.config = {
      type: Phaser.AUTO,
      scene: [ NewScene ],
      scale: {
        mode: Phaser.Scale.FIT,
        parent: 'gameContainer',
        height: 600,
        width: 600
      },
      physics: {
        default: 'arcade',
        arcade: {
          gravity: { y: 0 }
        }
      }
    };
  }

  ngOnInit() {
    this.phaserGame = new Phaser.Game(this.config);
  }

}
