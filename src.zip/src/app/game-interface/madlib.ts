
export interface Story {
    'Prural Noun': string[];
    'Noun1': string[];
    'Noun2': string[];
    'Animal': string[];
    'Adjective': string[];
}

export interface clickMatch {
    "key": string;
    "match": string
}
