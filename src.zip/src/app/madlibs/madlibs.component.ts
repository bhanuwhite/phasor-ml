import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-madlibs',
  templateUrl: './madlibs.component.html',
  styleUrls: ['./madlibs.component.scss']
})
export class MadlibsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
